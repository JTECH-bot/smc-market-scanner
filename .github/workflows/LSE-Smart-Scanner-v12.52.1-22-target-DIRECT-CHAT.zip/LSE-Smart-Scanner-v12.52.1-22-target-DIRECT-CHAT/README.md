# LSE Smart Scanner v12.52.1 — 22 Target Direct-Chat Package

## Telegram mode

This package uses **direct private Telegram chat delivery only**.

`TELEGRAM_GROUP_CHAT_ID` is not used anywhere.

Required bot environment variables:

- `BOT_TOKEN`
- `GITHUB_TOKEN`
- optional `GITHUB_REPOSITORY` (defaults to `JTECH-bot/smc-market-scanner`)
- optional `GITHUB_REF` (defaults to `main`)
- optional `SCANNER_WORKFLOW`

The bot receives `/scan` in a private chat, captures that chat ID, and passes it as the GitHub Actions `chat_id` workflow input. The workflow sends the validated result back to that same chat.

Required GitHub Actions repository secrets:

- `LSE_API_KEY`
- `BOT_TOKEN`
- `NEWS_RSS_URLS` (optional; external news is unavailable if omitted)

No `TELEGRAM_GROUP_CHAT_ID` secret is required.

## Workflow dispatch

The workflow has a required `chat_id` input for manual GitHub dispatch. The bot supplies it automatically.
